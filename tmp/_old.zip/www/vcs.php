<?php
mb_internal_encoding("UTF-8");
print_r($_POST);
exit();